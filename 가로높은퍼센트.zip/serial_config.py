serial_number = "CPAUTO10" 
